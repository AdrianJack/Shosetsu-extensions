# Extensions - Universe

Personal extensions for Shosetsu

#### Add the repo to shosetsu using this Url:

https://raw.githubusercontent.com/jobobby04/ShosetsuExtensions/master


### Repo Extensions
- [ArchiveOfOurOwn](https://archiveofourown.org/)
- [ReadWN](https://www.readwn.com/)
- [LightNovelMeta](https://www.lightnovelmeta.com/)
- [Wuxiap](https://www.wuxiap.com/)
- [FanNovel](https://www.fannovel.com/)
- [Hentai Foundry](https://www.hentai-foundry.com/)
